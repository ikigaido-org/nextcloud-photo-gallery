import type { FileTypeResult, Detector } from 'file-type';
type XmlTextEncoding = 'utf-8' | 'utf-16be' | 'utf-16le';
export declare function isXml(array: Uint8Array): {
    xml: true;
    encoding: XmlTextEncoding;
    offset: number;
} | {
    xml: false;
};
interface IXmlTextDetectorOptions {
    fullScan?: boolean;
}
export declare class XmlTextDetector {
    private options;
    private firstTag;
    private parser;
    private nesting;
    onEnd: boolean;
    fileType?: FileTypeResult;
    constructor(options?: IXmlTextDetectorOptions);
    write(text: string): void;
    close(): void;
    isValid(): boolean;
}
export declare const detectXml: Detector;
export {};
